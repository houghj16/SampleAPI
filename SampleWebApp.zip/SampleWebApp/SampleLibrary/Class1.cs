﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathLibrary
{
    public class Class1
    {
        public float Substract(float a, float b)
        {
            return a - b;
        }

        public float Multiply(float a, float b)
        {
            return a * b;
        }

        public float Divide(float a, float b)
        {
            return a / b;
        }

        public float Power(float a)
        {
            return a * a;
        }
    }
}